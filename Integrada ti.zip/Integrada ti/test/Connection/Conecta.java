/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


/**
 *
 * @author Samuelson
 */
public class Conecta {

    public static void main(String[] args) { 
        String url = "jdbc:mysql://localhost:3306/cursos"; 
        String user = "root"; // Usuário padrão do MySQL 
        String password = ""; // Senha do MySQL (vazia por padrão no XAMPP) 
  
        try { 
            // Carregar o driver JDBC do MySQL 
            Class.forName("com.mysql.cj.jdbc.Driver");  
  
            // Estabelecer conexão 
            Connection conn = DriverManager.getConnection(url, user, password); 
            System.out.println("Conectado ao banco de dados!"); 
  
            // Exemplo: Inserir um dado na tabela 
            String sqlInsert = "INSERT INTO minha_tabela (nome) VALUES (?)"; 
            PreparedStatement pstmtInsert = conn.prepareStatement(sqlInsert); 
            pstmtInsert.setString(1, "João"); 
            pstmtInsert.executeUpdate(); 
            System.out.println("Registro inserido com sucesso!"); 
  
            // Exemplo: Consultar dados da tabela 
            String sqlSelect = "SELECT * FROM minha_tabela"; 
            PreparedStatement pstmtSelect = conn.prepareStatement(sqlSelect); 
            ResultSet rs = pstmtSelect.executeQuery(); 
  
            while (rs.next()) { 
                int id = rs.getInt("id"); 
                String descricao = rs.getString("Curso"); 
                System.out.println("ID: " + id + ", Curso: " + descricao); 
            } 
  
            // Fechar conexão 
            conn.close(); 
        } catch (Exception e) { 
            e.printStackTrace(); 
        } 
    } 

    public static Connection getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static void closeConnection(Connection con, PreparedStatement stmt) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static void closeConnection(Connection con, PreparedStatement stmt, ResultSet rs) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
} 
